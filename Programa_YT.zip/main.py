import tkinter_root as tr


'''
MAIN: A partir de aquí comienza el Main.
'''
if __name__ == '__main__':
    my_window = tr.Window()
